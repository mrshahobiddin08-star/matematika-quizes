"""
Matritsalar va Determinant — Bilim Sinovi
Oddiy Flask serveri: bitta HTML sahifani (quiz + sertifikat generatori) beradi.
Faqat bepul kutubxonalar ishlatilgan: Flask va (production uchun) gunicorn.
"""
import os
from flask import Flask, render_template

app = Flask(__name__)


@app.route("/")
def index():
    return render_template("index.html")


# Bulutli platformalar (Render, Railway, PythonAnywhere va h.k.) uchun
# ular beradigan PORT muhit o'zgaruvchisini o'qiymiz, bo'lmasa 5000-portda ishga tushamiz.
if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    debug = os.environ.get("FLASK_DEBUG", "0") == "1"
    app.run(host="0.0.0.0", port=port, debug=debug)
